import './style/index.less'
import GameControl from './modules/GameControl'
new GameControl()