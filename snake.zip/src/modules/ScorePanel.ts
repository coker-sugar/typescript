// 记分牌类
class ScorePanel {
    score: number = 0;
    level: number = 1;
    scoreSpan: HTMLElement;
    levelEle: HTMLElement;
    // 设置变量限制等级
    maxLevel: number;
    // 设置一个变量多少分升等级
    upScore: number;
    constructor(maxLevel: number = 10,Score: number = 10) {
        this.scoreSpan = document.getElementById('score')!;
        this.levelEle = document.getElementById('level')!;
        this.maxLevel = maxLevel
        this.upScore =  Score
    }

    // 设置加分
    AddScore() {
        this.score ++;
        this.scoreSpan.innerHTML = this.score + ''
        if(this.score % this.upScore === 0) {
            this.Addlevel()
        }
    }
    // 提升等级
    Addlevel() {
        if(this.level < this.maxLevel) {
            this.levelEle.innerHTML = ++this.level + ''
        }
    }
}
// const sc = new ScorePanel();
// for(let i = 0;i < 100; i++) {
//     sc.AddScore()
// }
export default ScorePanel