class Snake {
    // 蛇头
    head: HTMLElement;
    bodies: HTMLCollectionOf<HTMLElement>;

    // 获取蛇的容器
    element: HTMLElement;
    constructor() {
        this.element = document.getElementById('snake')!;
        this.head = document.querySelector('#snake>div') as HTMLElement;
        this.bodies = this.element.getElementsByTagName('div');
    }


    // 获取蛇的坐标
    get X() {
        return this.head.offsetLeft;
    }
    get Y() {
        return this.head.offsetTop;
    }

    set X(value) {
        if(this.X === value) {
            return;
        }
        if(value < 0 || value > 290) {
            throw new Error('🐍撞墙了！')
        }
        // 修改x时，修改水平坐标，蛇在左右移动，蛇在向左移动时，不能向右掉头
        if(this.bodies[1] && (this.bodies[1] as HTMLElement).offsetLeft === value) {
            // 如果发生掉头，让蛇反方向继续移动
            if(value > this.X) {
                // value大于X，说明蛇在向右走，应该掉头，蛇向左走
                value = this.X - 10
            } else {
                value = this.X + 10
            }
        }
        this.moveBody();
        this.head.style.left = value + 'px'
        this.checkHeadBody()
    }

    set Y(value) {
        if(this.Y === value) return;
        if(value < 0 || value > 290) {
            throw new Error('🐍撞墙了！')
        }
        // 同理，修改y时，修改垂直坐标，蛇在上下移动，蛇在上下移动时，不能向下掉头
        if(this.bodies[1] && (this.bodies[1] as HTMLElement).offsetTop === value) {
            // 如果发生掉头，让蛇反方向继续移动
            if(value > this.Y) {
                value = this.Y - 10
            } else {
                value = this.Y + 10
            }
        }
        this.moveBody()
        this.head.style.top = value + 'px'
        this.checkHeadBody()
    }
    
    // 增加蛇的身体
    addBody() {
        this.element.insertAdjacentHTML("beforeend","<div></div>")
    }

    // 移动身体：将后面的身体放在前面去
    moveBody() {
        for(let i = this.bodies.length - 1;i > 0;i --) {
            // 获取身体的位置
            let x = (this.bodies[i - 1] as HTMLElement).offsetLeft;
            let y = (this.bodies[i - 1] as HTMLElement).offsetTop;
            // 将值设置到当前身体上
            (this.bodies[i] as HTMLElement).style.left = x + 'px';
            (this.bodies[i] as HTMLElement).style.top = y + 'px';
        }
    }

    // 检查蛇是否撞到自己
    checkHeadBody() {
        for(let i = 1;i < this.bodies.length;i ++) {
            if(this.X === this.bodies[i].offsetLeft && this.Y === this.bodies[i].offsetTop) {
                throw new Error('🐍撞到自己了！')
            }
        }
    }
}
// let snake = new Snake()
// console.log(`${snake.X} , ${snake.Y}`);
export default Snake