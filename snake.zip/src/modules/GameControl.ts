import Food from  './food'
import Snake from './Snake'
import ScorePanel from './ScorePanel'
// 游戏控制类，控制其它所有类
class GameControl {
    snake: Snake;
    food: Food;
    scorePanel: ScorePanel;
    direction: string = '';
    // 创建变量判断游戏是否结束
    isLive: boolean = true;
    constructor() {
        this.snake = new Snake();
        this.food = new Food();
        this.scorePanel = new ScorePanel();

        this.init();
    }
    // 游戏初始化
    init() {
        document.addEventListener('keydown',this.keydownHandler.bind(this))
        this.run()
    }
    // 键盘按下的响应函数
    keydownHandler(event: KeyboardEvent) {
        console.log(event.key);
        this.direction = event.key
    }
    // 控制蛇的移动，根据this.direction来使蛇位置改变
    run() {
        let X = this.snake.X;
        let Y = this.snake.Y;
        // 根据方向修改值
        switch(this.direction) {
            case 'ArrowUp':
            case 'Up':
                Y-=10;
                break;
            case 'ArrowDown':
            case 'Down':
                Y+=10;
                break;
            case 'ArrowLeft':
            case 'Left':
                X-=10;
                break;
            case 'ArrowRight':
            case 'Right':
                X+=10;
                break;
        }
        (this.checkEat(X,Y));
        try {
            // 修改X和Y值
            this.snake.X = X;
            this.snake.Y = Y;
        } catch(e) {
            alert((e as any).message + '游戏结束了！');
            this.isLive = false;
        }
        // 控制蛇前进的速度
        this.isLive && setTimeout(this.run.bind(this),200 - (this.scorePanel.level-1)*30)
    }
    // 检查蛇是否吃到食物
    checkEat(X:number,Y:number) {
        if(X === this.food.X && Y === this.food.Y) {
            // 食物位置重置
            this.food.change()
            // 分数增加
            this.scorePanel.AddScore()
            // 蛇加一节
            this.snake.addBody()
        }
    }
}
export default GameControl