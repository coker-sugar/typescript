# 前言
    仿造该博客https://blog.csdn.net/m0_52040370/article/details/126360586写的一个ts小游戏，目的是为了练习ts的写法，用ts思维写代码
    - 使用npm i安装依赖包
    - npm start启动项目
    - 使用< > ^ ⅴ 改变蛇移动的方向

# 1 项目结构

- html结构
  - 有一个游戏的大盒子 `main
  - 内部包有游戏舞台 `stage`和记分牌 `score-panel`
  - 游戏舞台内部有蛇 `snake`和食物 `food`
  - 记分分数 `score`和级别 `level`

- less结构
   - 设置主颜色：`@bg-color: #b7d4a8;`
   - 大盒子用flex布局，背景色为主颜色
   - 为了能让蛇和食物在舞台内部移动，利用子绝父相来实时改变蛇和食物的位置：`top` | `left`

# 2 Food类
1. 食物的元素定义：`element:HTMLElement`
2. 食物构造函数`constructor`中获取食物元素，`document.getElementById('food')!;`可能会提示为空，这时候只需要在语句后面加一个`！`即可
3. 获取当前食物的位置`get X() { return this.element.offsetLeft; }`
4. 改变食物坐标`change(){}`随机生成位置，在0-290之内
    
# 3 ScorePanel类
1. 有`levelEle`水平和`scoreSpan`分数两个元素
2. 设置最高水平`maxlevel`和最高分数`maxscore`
3. 加分方法`AddScore()`
4. 提升等级`Addlevel()`

# 4 Snake类
1. 注意操作蛇的时候，不是操作id为snake这个div，而是操作id为snake这个div下的div
2. 蛇包括`head: HTMLElement;`和`bodies:HTMLCollectionOf<HTMLElement>;`两个部分
3. 获取蛇元素的时候，要注意：
    ```typescript
    element: HTMLElement;
    constructor() {
        this.element = document.getElementById('snake')!;
        this.head = document.querySelector('#snake>div') as HTMLElement;
        this.bodies = this.element.getElementsByTagName('div');
    }
    ```
4. 获取蛇坐标`get X() | get Y()`
5. 设置蛇的位置：在0-290内活动
    ```typescript
    set X(value) {
        if(this.X === value) {
            return;
        }
        if(value < 0 || value > 290) {
            throw new Error('🐍撞墙了！')
        }
        // 修改x时，修改水平坐标，蛇在左右移动，蛇在向左移动时，不能向右掉头
        if(this.bodies[1] && (this.bodies[1] as HTMLElement).offsetLeft === value) {
            // 如果发生掉头，让蛇反方向继续移动
            if(value > this.X) {
                // value大于X，说明蛇在向右走，应该掉头，蛇向左走
                value = this.X - 10
            } else {
                value = this.X + 10
            }
        }
        this.moveBody();
        this.head.style.left = value + 'px'
        this.checkHeadBody()
    }
    ```
6. 增加蛇的身体
    ```typescript
    addBody() {
        this.element.insertAdjacentHTML("beforeend","<div></div>")
    }
    ```
7. 移动身体：将后面的身体放在前面去
    ```typescript
    moveBody() {
        for(let i = this.bodies.length - 1;i > 0;i --) {
            // 获取身体的位置
            let x = (this.bodies[i - 1] as HTMLElement).offsetLeft;
            let y = (this.bodies[i - 1] as HTMLElement).offsetTop;
            // 将值设置到当前身体上
            (this.bodies[i] as HTMLElement).style.left = x + 'px';
            (this.bodies[i] as HTMLElement).style.top = y + 'px';
        }
    }
    ```
8. 检查蛇是否撞到自己
    ```typescript
    checkHeadBody() {
        for(let i = 1;i < this.bodies.length;i ++) {
            if(this.X === this.bodies[i].offsetLeft && this.Y === this.bodies[i].offsetTop) {
                throw new Error('🐍撞到自己了!')
            }
        }
    }
    ```

# 5 GameControl类
1. 引入其它类
2. 初始化，构建其它类的实例
    ```typescript
     constructor() {
        this.snake = new Snake();
        this.food = new Food();
        this.scorePanel = new ScorePanel();

        this.init();
    }
    ```
3. 游戏初始化
    ```typescript
    init() {
        document.addEventListener('keydown',this.keydownHandler.bind(this))
        this.run()
    }
    ```
4. 键盘按下的响应函数
    ```typescript
    keydownHandler(event: KeyboardEvent) {
        console.log(event.key);
        this.direction = event.key
    }
    ```
5. 控制蛇的移动，根据this.direction来使蛇位置改变
    ```typescript
    run() {
        let X = this.snake.X;
        let Y = this.snake.Y;
        // 根据方向修改值
        switch(this.direction) {
            case 'ArrowUp':
            case 'Up':
                Y-=10;
                break;
            case 'ArrowDown':
            case 'Down':
                Y+=10;
                break;
            case 'ArrowLeft':
            case 'Left':
                X-=10;
                break;
            case 'ArrowRight':
            case 'Right':
                X+=10;
                break;
        }
        (this.checkEat(X,Y));
        try {
            // 修改X和Y值
            this.snake.X = X;
            this.snake.Y = Y;
        } catch(e) {
            alert((e as any).message + '游戏结束了！');
            this.isLive = false;
        }
        this.isLive && setTimeout(this.run.bind(this),200 - (this.scorePanel.level-1)*30)
    }
    ```
6. 检查蛇是否吃到食物
    ```typescript
    checkEat(X:number,Y:number) {
        if(X === this.food.X && Y === this.food.Y) {
            // 食物位置重置
            this.food.change()
            // 分数增加
            this.scorePanel.AddScore()
            // 蛇加一节
            this.snake.addBody()
        }
    }
    ```